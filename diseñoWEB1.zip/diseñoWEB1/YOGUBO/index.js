var boton1 = document.getElementById('boton1');
var boton2 = document.getElementById('boton2');
var boton3 = document.getElementById('boton3');

function cambio1(){
    boton1.style.display="block";
}

function cambio1f(){
    boton1.style.display="none";
}

function cambio2(){
    boton2.style.display="block";
}

function cambio2f(){
    boton2.style.display="none";
}

function cambio3(){
    boton3.style.display="block";
}

function cambio3f(){
    boton3.style.display="none";
}

